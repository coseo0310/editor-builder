import Editor from "./module/editor.js";

let URL = "";

const editorWrap = document.querySelector(".editor-wrap");
const initEl = document.querySelector(".init");
const widthFit = document.querySelector(".width-fit");
const heightFit = document.querySelector(".height-fit");
const rotateLeft = document.querySelector(".rotate-left");
const rotateRight = document.querySelector(".rotate-right");
const zoomIn = document.querySelector(".zoom-in");
const zoomOut = document.querySelector(".zoom-out");
const text = document.querySelector(".text");
const idx = document.querySelector(".index");
const readonlyEl = document.querySelector(".readonly");
const draw = document.querySelector(".draw");
const download = document.querySelector(".download");
const list = document.querySelector(".list");

let zoom = 100;
let rotate = 0;
let isText = false;
let isIndex = true;
let isReadOnly = false;
let fields = [];

let scroll = { x: 0, y: 0 };

init();

function init() {
  const editor = new Editor();
  const canvasElement = editor.getCanvas();

  rotate = 0;
  zoom = editor.getScale() * 100;

  editor.addEventListener("imgLoaded", () => {
    widthFit.click();
  });

  editorWrap.addEventListener("scroll", () => {
    const { x, y } = canvasElement.getBoundingClientRect();
    scroll.x = x;
    scroll.y = y;
  });

  editorWrap.innerHTML = "";
  editorWrap.appendChild(canvasElement);
  editor.setIsText(isText);
  setImage(editor);
  setFieldData(editor);
  setEvent(editor);
}

// BTN Add Events
function setEvent(e) {
  // 초기화
  initEl.addEventListener("click", () => {
    zoom = 100;
    rotate = 0;
    isText = false;
    isIndex = true;
    isReadOnly = false;

    e.clearEditField();
    e.removeFields();
    setFieldData(e);

    e.setRotate(rotate);
    e.setZoomInOut(zoom);
    e.setIsText(isText);
    widthFit.click();
  });

  // 좌우폭 맞춤
  widthFit.addEventListener("click", () => {
    e.setCalculatedScale();
    zoom = e.getScale() * 100;
  });

  // 상하 맞춤
  heightFit.addEventListener("click", () => {
    e.setCalculatedScale("height");
    zoom = e.getScale() * 100;
  });

  // 90deg 회전
  rotateLeft.addEventListener("click", () => {
    rotate += 90;
    e.setRotate(rotate);
  });

  // -90deg 회전
  rotateRight.addEventListener("click", () => {
    rotate -= 90;
    e.setRotate(rotate);
  });

  // Zoom In
  zoomIn.addEventListener("click", () => {
    zoom += 10;
    e.setZoomInOut(zoom);

    scroll.x = scroll.x / (zoom / 100);
    scroll.y = scroll.y / (zoom / 100);

    editorWrap.scrollTo({
      left: Math.abs(scroll.x),
      top: Math.abs(scroll.y),
      behavior: "auto",
    });
  });

  // Zoom Out
  zoomOut.addEventListener("click", () => {
    zoom -= 10;
    e.setZoomInOut(zoom);

    scroll.x = scroll.x * (zoom / 100);
    scroll.y = scroll.y * (zoom / 100);

    editorWrap.scrollTo({
      left: Math.abs(scroll.x),
      top: Math.abs(scroll.y),
      behavior: "auto",
    });
  });

  // Text ON/OFF
  text.addEventListener("click", () => {
    isText = !isText;
    e.setIsText(isText);
    e.draw();
  });

  // Index ON/OFF
  idx.addEventListener("click", () => {
    isIndex = !isIndex;
    e.setIsIdx(isIndex);
    e.draw();
  });

  // Readonly ON/OFF
  readonlyEl.addEventListener("click", () => {
    isReadOnly = !isReadOnly;
    e.setIsReadonly(isReadOnly);
  });

  // New Draw
  draw.addEventListener("click", () => {
    e.setDraw("new");
  });

  // Download
  download.addEventListener("click", () => {
    e.downloadImage();
  });
}

// 이미지 설정
function setImage(e) {
  const image = new Image();
  image.src = "./sample/temp1.jpg";

  image.onload = () => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;

    ctx.drawImage(
      image,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight
    );

    URL = canvas.toDataURL("image/png");
    e.setImgUrl(URL);
  };
}

// 필드 데이터 입력
function setFieldData(e) {
  const items = [
    {
      id: "kv-000",
      text: "20191112",
      dx: 854.7839965820312,
      dy: 3151.008056640625,
      dWidth: 379.00799560546875,
      dHeight: 48.384033203125,
      type: "miss",
      lineWidth: 5,
    },
    {
      id: "kv-001",
      text: "박희붕외과의원",
      dx: 782.2080078125,
      dy: 3253.823974609375,
      dWidth: 306.4320068359375,
      dHeight: 48.384033203125,
      type: "error",
      lineWidth: 5,
    },
    {
      id: "kv-002",
      text: "경기 수원시 권선구 권선동 1013 지오베르크 203호",
      dx: 782.2080078125,
      dy: 3359.6640625,
      dWidth: 1052.35205078125,
      dHeight: 48.384033203125,
      type: "confirm",
      lineWidth: 5,
    },
    {
      id: "kv-003",
      text: "031-233-5571",
      dx: 778.176025390625,
      dy: 3462.47998046875,
      dWidth: 310.4639892578125,
      dHeight: 39.31201171875,
      type: "miss",
      lineWidth: 5,
    },
    {
      id: "kv-004",
      text: "유방의 진단영상검사상 이상소견 유방의 다발 양성 신생물/ 상세불명 쪽",
      dx: 693.5040283203125,
      dy: 967.6799926757812,
      dWidth: 725.760009765625,
      dHeight: 102.81597900390625,
      type: "confirm",
      lineWidth: 5,
    },
    {
      id: "kv-005",
      text: "R92 D2439",
      dx: 2342.592041015625,
      dy: 964.656005859375,
      dWidth: 129.02392578125,
      dHeight: 96.7679443359375,
      type: "error",
      lineWidth: 5,
    },
    {
      id: "kv-006",
      text: "20191112",
      dx: 806.4000244140625,
      dy: 1684.3680419921875,
      dWidth: 262.0799560546875,
      dHeight: 39.31201171875,
      type: "miss",
      lineWidth: 5,
    },
  ];

  e.setFields(items);

  fields = e.getFields();

  list.innerHTML = ``;

  fields.forEach((item, idx) => {
    const items = document.createElement("div");
    items.classList.add("items");
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "text";
    input.value = item.text;
    label.innerText = idx + 1;

    items.appendChild(label);
    items.appendChild(input);
    list.appendChild(items);

    input.addEventListener("keyup", (event) => {
      const v = event.target.value;
      item.text = v;
      e.modifyField(item);
      e.draw();
    });
  });
}
