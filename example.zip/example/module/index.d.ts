import Editor from "./EditorController";
import { EditorTypes } from "./types";
declare type Field = EditorTypes.Field;
export { Field };
export default Editor;
